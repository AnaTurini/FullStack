var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');

var app = express();
app.use(express.static('./public/'));
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);
server.listen(80);

console.log('Servidor rodando ...'.rainbow);

app.get('/', function (requisicao, resposta){
resposta.redirect('login.html')
})

app.get('/cadastra',function (requisicao, resposta){
var nome = requisicao.query.nome;
var sobrenome = requisicao.query.sobrenome;
var nascimento = requisicao.query.nascimento;
var usuario = requisicao.query.usuario;
var senha = requisicao.query.senha;

resposta.render('resposta_cadastro', {nome, sobrenome, nascimento, usuario, senha})
})

app.get('/login',function (requisicao, resposta){
var usuario = requisicao.query.usuario;
var senha = requisicao.query.senha;
resposta.render('resposta_login',{usuario,senha})
})
