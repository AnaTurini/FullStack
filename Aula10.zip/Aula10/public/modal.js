function abrirModal(id, marca, modelo, ano, qtde) {
            document.getElementById('modal-id').value    = id;
            document.getElementById('modal-marca').value  = marca;
            document.getElementById('modal-modelo').value = modelo;
            document.getElementById('modal-ano').value    = ano;
            document.getElementById('modal-qtde').value   = qtde;
            document.getElementById('modalBg').classList.add('ativo');
        }

        function fecharModal() {
            document.getElementById('modalBg').classList.remove('ativo');
        }

        document.getElementById('modalBg').addEventListener('click', function(e) {
            if (e.target === this) fecharModal();
        });