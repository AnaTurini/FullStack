var http = require('http'); 
var express = require('express'); 
var colors = require('colors'); 
var bodyParser = require('body-parser'); 
var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;
const uri = "mongodb://aninha:1234@ac-op8ygio-shard-00-00.hksuhga.mongodb.net:27017,ac-op8ygio-shard-00-01.hksuhga.mongodb.net:27017,ac-op8ygio-shard-00-02.hksuhga.mongodb.net:27017/?ssl=true&replicaSet=atlas-12zsnp-shard-0&authSource=admin&appName=FullStack";
const client = new MongoClient(uri);
var posts;
var usuarios;
var carros;
async function conectar() {
    await client.connect();
    console.log("Mongo conectado!");
    const dbo = client.db("blog");
    posts = dbo.collection("posts");
    usuarios = dbo.collection("usuarios");
    carros = dbo.collection("carros");
    console.log("Collections criadas!");
}
conectar();
var app = express();
app.use(express.static('./public/'));
app.use(bodyParser.urlencoded({ extended: false})) 
app.use(bodyParser.json())
app.set('view engine', 'ejs') 
app.set('views', './views'); 
var server = http.createServer(app); 
server.listen(80); 
console.log('Servidor rodando ...'.rainbow);

var ObjectId = mongodb.ObjectId;

async function cadastrarCarro(marca, modelo, ano, qtde) {
    var data = {
        db_marca: marca,
        db_modelo: modelo,
        db_ano: parseInt(ano),
        db_qtde_disponivel: parseInt(qtde)
    };
    return await carros.insertOne(data);
}

async function buscarTodosCarros() {
    return await carros.find({}).toArray();
}

async function atualizarCarro(id, marca, modelo, ano, qtde) {
    var filtro  = { _id: new ObjectId(id) };
    var newData = { $set: {
        db_marca: marca,
        db_modelo: modelo,
        db_ano: parseInt(ano),
        db_qtde_disponivel: parseInt(qtde)
    }};
    return await carros.updateOne(filtro, newData);
}

async function removerCarro(id) {
    var filtro = { _id: new ObjectId(id) };
    return await carros.deleteOne(filtro);
}

async function venderCarro(id) {
    var filtro  = { _id: new ObjectId(id), db_qtde_disponivel: { $gt: 0 } };
    var newData = { $inc: { db_qtde_disponivel: -1 } };
    return await carros.updateOne(filtro, newData);
}

app.get('/cadastro_usuario', function(req, res) {
    res.sendFile('cadastro_usuario.html', { root: './public' });
});

app.get('/login_usuario', function(req, res) {
    res.sendFile('login_usuario.html', { root: './public' });
});

app.post('/cadastrar_usuario_carros', async function(req, res) {

    var data = {
        db_nome: req.body.nome,
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    try {

        await usuarios.insertOne(data);

        res.redirect('/login_usuario');

    } catch(err) {

        console.log(err);

        res.send(`
            <body style="
                background-color: rgb(37, 51, 82);
                color: #e0e0e0;
                font-family: 'Times New Roman';
                display:flex;
                justify-content:center;
                align-items:center;
                height:100vh;
                margin:0;
            ">
                <div style="
                    background:#a0a0b0;
                    color: rgb(37, 51, 82);
                    padding:40px;
                    border-radius:20px;
                    text-align:center;
                ">
                    <h1>Erro ao cadastrar usuário.</h1>
                </div>
            </body>
        `);

    }
});
app.post('/logar_usuario_carros', async function(req, res) {
    var data = { db_login: req.body.login, db_senha: req.body.senha };
    try {
        const items = await usuarios.find(data).toArray();
        if (items.length === 0) {
            res.send("Usuário/senha não encontrado!");
        } else {
            res.redirect('/carros');
        }
    } catch(err) {
        res.send("Erro ao fazer login.");
    }
});

app.get('/', function(req, res) {
    res.redirect('/carros');
});

app.get('/carros', async function(req, res) {
    try {
        const listaCarros = await buscarTodosCarros();
        res.render('carros', { carros: listaCarros });
    } catch (err) {
        console.error("Erro ao buscar carros:", err);
        res.render('carros', { carros: [] });
    }
});

app.get('/gerenciar_carros', async function(req, res) {
    try {
        const listaCarros = await buscarTodosCarros();
        res.render('gerenciar_carros', { carros: listaCarros });
    } catch (err) {
        console.error("Erro ao buscar carros:", err);
        res.render('gerenciar_carros', { carros: [] });
    }
});

app.post('/cadastrar_carro', async function(req, res) {
    try {
        await cadastrarCarro(req.body.marca, req.body.modelo, req.body.ano, req.body.qtde);
        res.redirect('/gerenciar_carros');
    } catch (err) {
        console.error("Erro ao cadastrar carro:", err);
        res.send("Erro ao cadastrar carro.");
    }
});

app.post('/atualizar_carro', async function(req, res) {
    try {
        await atualizarCarro(req.body.id, req.body.marca, req.body.modelo, req.body.ano, req.body.qtde);
        res.redirect('/gerenciar_carros');
    } catch (err) {
        console.error("Erro ao atualizar carro:", err);
        res.send("Erro ao atualizar carro.");
    }
});

app.post('/remover_carro', async function(req, res) {
    try {
        await removerCarro(req.body.id);
        res.redirect('/gerenciar_carros');
    } catch (err) {
        console.error("Erro ao remover carro:", err);
        res.send("Erro ao remover carro.");
    }
});

app.post('/vender_carro', async function(req, res) {
    try {
        await venderCarro(req.body.id);
        res.redirect('/gerenciar_carros');
    } catch (err) {
        console.error("Erro ao vender carro:", err);
        res.send("Erro ao vender carro.");
    }
});
